ACRConfig = {
    host : 'identify-us-west-2.acrcloud.com',
    endpoint: '/v1/identify',
    signature_version: '1',
    data_type:'audio',
    secure: true,
    access_key: '56294c96f82e08edbc642fcd832cb5b2',
    access_secret: 'kHZsQfuyfvLLHjIJlI27K95sGBvp6GI4DamKOifP'
};

module.exports = ACRConfig